package com.cs491.vendar.model;

public enum Role {
    USER,
    ADMIN
}
