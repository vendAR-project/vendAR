package com.cs491.vendar.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
public class DemoController {
    
    @GetMapping("/demo")
    public ResponseEntity<String> demo (){
        System.out.println("Check");
        return ResponseEntity.ok("DEMOCONTR");
    }
}
