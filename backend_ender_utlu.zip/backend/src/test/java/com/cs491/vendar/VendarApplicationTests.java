package com.cs491.vendar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendarApplicationTests {

	@Test
	void contextLoads() {
	}

}
